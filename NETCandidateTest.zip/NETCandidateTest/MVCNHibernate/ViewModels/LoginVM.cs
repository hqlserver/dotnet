﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCNHibernate.ViewModels
{
    public class LoginVM
    {
        [DisplayName("Username")]
        [Required(ErrorMessage = "Please enter Username")]
        public string UserName { get; set; }

        [DisplayName("Password")]
        [Required(ErrorMessage = "Please enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}