﻿using MVCNHibernate.Utils;
using MVCNHibernate.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCNHibernate.Controllers
{
    public class UserController : Controller
    {
        public ActionResult Login(LoginVM vm)
        {
            if (ModelState.IsValid)
            {
                SecurityService secService = new SecurityService();
                Models.User loggedUser = secService.AuthenticateUser(vm.UserName, vm.Password);
                if (loggedUser != null)
                {
                    return RedirectToAction("LoginSuccess", "User");
                }
                else
                {
                    ModelState.AddModelError("", "Login failed, please try again");
                }
            }
            return View();
        }

        public ActionResult LoginSuccess()
        {
            return View();
        }
    }
}
