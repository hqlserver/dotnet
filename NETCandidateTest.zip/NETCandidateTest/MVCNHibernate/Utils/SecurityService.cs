﻿using MVCNHibernate.Models;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCNHibernate.Utils
{
    public class SecurityService
    {
        public User AuthenticateUser(string username, string pwd)
        {
            using (var session = NHFactoryManager.GetSession())
            {
                var users = session.CreateCriteria<User>()
                                    .Add(Restrictions.Eq("UserName", username))
                                    .Add(Restrictions.Eq("Password", pwd))
                                    .List();
                if (users.Count > 0)
                {
                    User loggedUser = new User();
                    loggedUser.UserName = username;
                    return loggedUser;
                }
            }

            return null;
        }
    }
}